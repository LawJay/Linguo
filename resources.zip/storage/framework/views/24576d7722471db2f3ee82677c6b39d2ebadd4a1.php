<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="row new-post">
	<div class="col-md-6 col-md-offset-3">
		<header><h3> What's on your mind?</h3></header>
		<form action="<?php echo e(route('post.create')); ?>" method="POST">
			<div class="form-group">
				<textarea  class="form-control" name="body" id="new-post" rows="10" placeholder="Start typing here..."></textarea>
			</div>
			<button type="submit" class="btnn btn-primary">Submit</button>
			<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
		</form>
	</div>
</section>
<section class="row posts">
	<div class="col-md-6 col-md-offset-3">
			<header><h3>What's new...</h3></header>

				<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<article class="post">
				<p><?php echo e($post->body); ?></p>

				<div class="info">
				<small> Posted by <?php echo e($post->user->name); ?> <?php echo e($post->created_at); ?></small>
				</div>
				<div class="interaction">
					<a href="#">Like</a>
					<a href="#">Dislike</a>

					<?php if(Auth::user() == $post->user): ?>
					|

						<a href="#">Edit</a>
					<a href="<?php echo e(route('post.delete', ['post_id' => $post->id])); ?>">Delete</a>
					<?php endif; ?>
					
				</div>
				</article>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			

	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>