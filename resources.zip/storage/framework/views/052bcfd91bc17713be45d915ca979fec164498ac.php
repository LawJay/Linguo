<?php $__env->startSection('title'); ?>

Welcome!
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-6">
            <h3>Sign Up!</h3>
            <form action="<?php echo e(route('signup')); ?>" method="POST">
                <div class="form-group">
                    <label for"email"> E-Mail</label>
                    <input class="form-control <?php echo e($errors->has('email') ? 'has-error' : ''); ?>"type="text" name="email" id="email"  value="<?php echo e(Request::old('email')); ?>">

                </div>

                <div class="form-group">
                    <label for"name"> Name</label>
                    <input class="form-control <?php echo e($errors->has('name') ? 'has-error' : ''); ?>"type="text" name="name" id="name" value="<?php echo e(Request::old('name')); ?>">
                    
                </div>

                <div class="form-group">
                    <label for"password">Password</label>
                    <input class="form-control <?php echo e($errors->has('password') ? 'has-error' : ''); ?>"type="password" name="password" id="password" value="<?php echo e(Request::old('password')); ?>">
                    
                </div>

                <button type="submit" class="btn btn-primary">Sign Up</button>

                    <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
            </form>
            
        </div>
        <div class="col-md-6">
            <h3>Sign in!</h3>
            <form action="<?php echo e(route('signin')); ?>" method="POST">
                <div class="form-group">
                    <label for"email"> E-Mail</label>
                    <input class="form-control"type="text" name="email" id="email">

                </div>

                <div class="form-group">
                    <label for"password">Password</label>
                    <input class="form-control"type="password" name="password" id="password">
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
            </form>
            
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>